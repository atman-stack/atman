<template>
    <div>
        <carousel></carousel>
        <inputs></inputs>

        
    </div>
</template>
<script>

import Inputs from "./components/Inputs";

import Carousel from "./components/Carousel";


export default {
  name: "components",
  components: {

    Inputs,

    Carousel

  }
};
</script>
