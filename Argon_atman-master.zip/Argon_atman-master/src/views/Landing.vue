<template>
    <div>

    
        <section class="container  mt-5">
                   <div class=" col-lg-12 ">
                       <div class="d-flex align-items-center flex-column">
                            <img class="point mt-5 p-2" src="img/theme/point.jpg" alt="mon image" >
                        
                        
                            <h5 class="p-2"> paragraphe d introduction</h5>

                            <h5 class="p-2"> tout d'abord qu'est ce qu'une crise d'epilepsie??</h5>
                        </div>
                    </div>
                        <p >
                            La crise convulsive est donc le phénomène élémentaire dont la répétition définit l’épilepsie.
                            Le cerveau est le centre de régulation et de communication de l’organisme : il nous fournit nos facultés de perception,
                            de communication, de mémorisation, de compréhension, de jugement et d’accomplissement de mouvements volontaires.
                            Il est constitué de tissu nerveux essentiellement composé de neurones. Ce sont des cellules qui, au moyen de signaux  électriques
                            , génèrent les informations conditionnant la plupart des fonctions du corps.
                            
                            La substance grise est composée des corps cellulaires des neurones.
                            La substance blanche est constituée des ramifications des neurones (axones) permettant la transmission de l’information et les contacts entre différents neurones,
                            le tout formant un réseau très complexe.
                            Le cerveau est divisé en deux hémisphères reliés entre eux.
                            On distingue dans les hémisphères des zones correspondants à des fonctions spécifiques (aires motrices, aires sensitives, aires associatives).
                            
                            Une crise convulsive est un symptôme : elle résulte du fait qu’un ou plusieurs groupes de neurones,
                            ou parfois la totalité du cerveau, présentent des décharges électriques paroxystiques synchrones (c'est-à-dire survenant sans prévenir, en même temps), liées à une hyperexcitabilité.
                            Elle a été historiquement définie par Jackson comme étant « la survenue épisodique d’une décharge brusque, 
                            excessive et rapide d’une population plus ou moins étendue de neurones qui constituent la substance grise de l’encéphale ».
                            
                            Elle peut être :
                            
                            Le symptôme d’un évenement aigu : on parle alors d’épilepsie secondaire ou « symptomatique » (dûe à une pathologie sous-jacente)
                            Le symptôme d’une maladie épileptique : on parle alors d’épilepsie primaire ou d’épilepsie maladie
                            On estime qu’environ 2 à 5% de la population fera un jour une crise convulsive.
                            
                            L’épilepsie «maladie» (épilepsie primaire), est un ensemble de maladies permanentes caractérisées par une tendance à la répétition de plusieurs crises convulsives.
                            Généralement, les patients font toujours le même type de crises, stéréotypées.
                            On considère qu’elle touche environ 0.5 à 1% de la population.
                            La crise convulsive est donc un symptôme et c'est sa répétition qui définit l’épilepsie.
                            Devant une première crise convulsive (dite «crise inaugurale »), on ne pourra conclure à une épilepsie «maladie» qu’après avoir éliminé une épilepsie secondaire à pathologie sous jacente.

                        </p>
                 
        </section>
       


    </div>
</template>

<script>
export default {
  name: "home",
  components: {}
};
</script>

