<template>
    <section class="section section-shaped section-lg my-0">
        <div >
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>
        <div class="container pt-lg-md">
            <div class="row justify-content-center">
      

                      

                                    <div class="col-lg-6 col-md-6 col-sm-12 mt-4 bg-default">
                                        <h3 class="text-white text-center">Ecrivez nous votre message.</h3>
                                        <form action="" method="">
                                            <div class="form-group">
                                                <input class="form-control mt-3" type="text" name="name" id="name" placeholder="name">
                                            </div>
                                            <div class="form-group">
                                                <input class="form-control mt-3" type="email" name="email" id="email" placeholder="email">
                                            </div>
                                            <div class="form-group">
                                                <textarea class="form-control" name="" id="" cols="30" rows="4" placeholder="Votre Message"></textarea>
                                            </div>
                                            <div class="form-group">
                                                <button class="btn btn-primary form-control">Valider</button>
                                            </div>
                                        </form>
                                    </div>
                         

                    


                </div>
            </div>
       
    </section>
</template>
<script>
export default {};
</script>
<style>
</style>
