<template>

        <div class="container mb-5 bg-default">
  
            <h3 class="h4 text-white font-weight-bold mb-4 ">Inputs</h3>

            <div class="row ">
                <div class="container MarginElement">
                    <div class="row ">
                        <div class="col-lg-4 col-md-6 col-sm-12 mb-4 ">
                            <div class="" >
                                <h5><i class="fas fa-leaf mr-4 RetinaReady text-white font-weight-bold"></i><span class="text-white font-weight-bold">Retina Ready</span></h5>
                            </div>
                            <div>
                                <p>
                                </p>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                            <div>
                                <h5><i class="fas fa-leaf mr-4 RetinaReady text-white font-weight-bold"></i><span class="text-white font-weight-bold">Parralax Effects</span></h5>
                            </div>
                                <p>
                                </p>
                        </div>

                        <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                            <div>
                                <h5><i class="fas fa-leaf mr-4 RetinaReady text-white font-weight-bold"></i><span class="text-white font-weight-bold">Creative Solutions</span></h5>
                            </div>
                                <p>
                                </p>
                        </div>

                        <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                            <div>
                                <h5><i class="fas fa-leaf mr-4 RetinaReady text-white font-weight-bold"></i><span class="text-white font-weight-bold">Creative Blog Style</span></h5>
                            </div>
                                <p>
                                </p>
                            </div>

                        <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                            <div>
                                <h5><i class="fas fa-leaf mr-4 RetinaReady text-white font-weight-bold"></i><span class="text-white font-weight-bold">Amazing Interface</span></h5>
                            </div>
                                <p>
                                </p>
                        </div>

                        <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                            <div>
                                <h5><i class="fas fa-leaf mr-4 RetinaReady text-white font-weight-bold"></i><span class="text-white font-weight-bold">Mega Menus</span></h5>
                            </div>
                                <p>
                                </p>
                        </div>

                            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                                <div>
                                    <h5><i class="fas fa-leaf mr-4 RetinaReady text-white font-weight-bold"></i><span class="text-white font-weight-bold">Icon Fonts</span></h5>
                                </div>
                                    <p>
                                    </p>
                                </div>

                        <div class="col-lg-4 col-md-6 col-sm-12 mb-3">
                            <div>
                                <h5><i class="fas fa-leaf mr-4 RetinaReady text-white font-weight-bold"></i><span class="text-white font-weight-bold">SEO Optimized</span></h5>
                            </div>
                                <p>
                                </p>
                        </div>

                        <div class="col-lg-4 col-md-6 col-sm-12">
                            <div>
                                <h5><i class="fas fa-leaf mr-4 RetinaReady text-white font-weight-bold"></i><span class="text-white font-weight-bold">Custom Backgrounds</span></h5>
                            </div>
                                <p>
                                </p>
                            </div>
                    </div>
                </div>
            </div>
        </div>


</template>
<script>
export default {};
</script>
<style>

</style>
