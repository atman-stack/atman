<template>
    <ul class="navbar-nav ml-auto">
        <li class="nav-item">
            <a class="nav-link nav-link-icon" href="#">
                <i class="fa fa-facebook-square"></i>
                <span class="nav-link-inner--text">Facebook</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link nav-link-icon" href="#">
                <i class="fa fa-twitter"></i>
                <span class="nav-link-inner--text">Twitter</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link nav-link-icon" href="#">
                <i class="fa fa-instagram"></i>
                <span class="nav-link-inner--text">Instagram</span>
            </a>
        </li>
    </ul>
</template>
<script>
export default {};
</script>
<style>
</style>
